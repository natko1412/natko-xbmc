from __future__ import unicode_literals
import urllib2
import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
from BeautifulSoup import BeautifulSoup as bs

import datetime
import json
import sqlite3


YOUTUBE_API_KEY='AIzaSyDIwXfF0WjgTUwuazYIc7SFDqr576b_xs4'





def delete_database():
    #DROP TABLE IF EXISTS TABLE_NAME;
    db=sqlite3.connect('folders.db')

    with db:
    
        cur = db.cursor()    
    
        cur.execute("drop table if exists Folders")
        cur.execute("drop table if exists Channels")
    return

def read_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:33.0) Gecko/20100101 Firefox/33.0')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link.decode('utf-8')

def init_database():
    db=sqlite3.connect('folders.db')

    with db:
    
        cur = db.cursor()    
    
        cur.execute("create table if not exists Folders (Name TEXT, Channel TEXT)")
        cur.execute("create table if not exists Channels (Folder TEXT, Channel TEXT, Channel_ID TEXT,thumb TEXT)")
    
    return
def get_folders():
    init_database()
    db=sqlite3.connect('folders.db')

    cur = db.cursor()    
    cur.execute("SELECT Name FROM Folders")

    rows = cur.fetchall()
    folders=[]
    for i in range (len(rows)):
        folder=rows[i]
        folders+=folder
    

    
    return folders

def add_folder(foldername):
    init_database()

    db=sqlite3.connect('folders.db')

    cur = db.cursor()    
    cur.execute("INSERT INTO Folders(Name) VALUES ('%s');"%foldername)

    db.commit()

def remove_folder(name):
    #DELETE FROM COMPANY WHERE ID = 7

    db=sqlite3.connect('folders.db')

    cur = db.cursor()    
    cur.execute("DELETE FROM Folders WHERE Name = ?;",(name,))

    db.commit()

    cur = db.cursor()    
    cur.execute("DELETE FROM Channels WHERE Folder = ?;",(name,))

    db.commit()


def get_channels(foldername):
    db=sqlite3.connect('folders.db')

    cur = db.cursor()    
    cur.execute("SELECT Channel,Channel_ID,thumb FROM Channels WHERE Folder=?",(foldername,))

    rows = cur.fetchall()
    channels=[]
    print('ROWS:')
    
    for i in range (len(rows)):
        channel=list(rows[i])
        channels+=[channel]
    return channels

def add_channel(foldername,channel_name,channel_id,thumb):
    db=sqlite3.connect('folders.db')

    cur = db.cursor()    
    cur.execute("INSERT INTO Channels(Folder,Channel,Channel_ID,thumb) VALUES (?,?,?,?);",(foldername,channel_name,channel_id,thumb))

    db.commit()

def remove_channel(id):
    #DELETE FROM COMPANY WHERE ID = 7

    db=sqlite3.connect('folders.db')

    cur = db.cursor()    
    cur.execute("DELETE FROM Channels WHERE Channel_ID = ?;",(id,))

    db.commit()

def search_channel(channel_name):

    my_addon = xbmcaddon.Addon()
    result_num = my_addon.getSetting('result_number_channels')


    req_url='https://www.googleapis.com/youtube/v3/search?q=%s&type=channel&part=snippet&maxResults=%s&key=%s'%(channel_name.replace(' ','%20'),str(result_num),YOUTUBE_API_KEY)
    #req_url='https://www.googleapis.com/youtube/v3/search?q=%stype=channel&maxResults=20&part=snippet&key='%channel_name.replace(' ','%20') + YOUTUBE_API_KEY
    read=read_url(req_url)
    decoded_data=json.loads(read)
    listout=[]
    
    for x in range(0, len(decoded_data['items'])):
        title=decoded_data['items'][x]['snippet']['title']
        thumb=decoded_data['items'][x]['snippet']['thumbnails']['high']['url']
        channel_id=decoded_data['items'][x]['snippet']['channelId']
        req1='https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=%s&key=AIzaSyAO7A3iaRS6RJOYUf-o9caPPK-aiMcrnEk'%channel_id
        read2=read_url(req1)
        decoded_data2=json.loads(read2)
        
        channel_id=decoded_data2['items'][0]['contentDetails']['relatedPlaylists']['uploads']
        listout.append([title,channel_id,thumb])
        




        
    print(listout)
    return listout


def get_latest_from_channel(channel_id, page):

    my_addon = xbmcaddon.Addon()
    result_num = my_addon.getSetting('result_number')

    if page=='1':
        req_url='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=%s&playlistId=%s&key='%(str(result_num),channel_id)+YOUTUBE_API_KEY
    else:
        req_url='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&pageToken=%s&maxResults=20&playlistId=%s&key='%(page,channel_id)+YOUTUBE_API_KEY
    read=read_url(req_url)
    decoded_data=json.loads(read)
    listout=[]
    next_page=decoded_data['nextPageToken']
    listout.append(next_page)
    for x in range(0, len(decoded_data['items'])):
        title=decoded_data['items'][x]['snippet']['title']
        video_id=decoded_data['items'][x]['snippet']['resourceId']['videoId']
        thumb=decoded_data['items'][x]['snippet']['thumbnails']['high']['url']
        desc=decoded_data['items'][x]['snippet']['description']
        listout.append([title,video_id,thumb,desc])
    return listout

                

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)


if mode is None:
    folders=get_folders()
    print(folders)
    
    for i in range(len(folders)):
        url = build_url({'mode': 'open_folder', 'foldername': '%s'%folders[i]})
        li = xbmcgui.ListItem('%s'%folders[i], iconImage='http://icons.iconarchive.com/icons/designbolts/shaded-social/256/Youtube-icon.png')

        rem_uri = build_url({'mode': 'rem_folder', 'foldername': '%s'%str(folders[i])})
        li.addContextMenuItems([ ('Remove folder', 'RunPlugin(%s)'%rem_uri)])


        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)



    url = build_url({'mode': 'add_folder', 'foldername': 'Add folder'})
    li = xbmcgui.ListItem('[COLOR green]Add folder[/COLOR]', iconImage='https://cdn4.iconfinder.com/data/icons/linecon/512/add-512.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
                              

    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0]=='del_all':
    delete_database()
    xbmc.executebuiltin("Container.Refresh")

elif mode[0]=='add_folder':
    keyboard = xbmc.Keyboard('', 'Folder name:', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        folder_name = keyboard.getText()

        add_folder(folder_name)
    xbmc.executebuiltin("Container.Refresh")

elif mode[0]=='open_folder':

    dicti=urlparse.parse_qs(sys.argv[2][1:])
    foldername=dicti['foldername'][0]
    
    channels=get_channels(foldername)
    print('Channels: ',channels)
    for i in range(len(channels)):
        url = build_url({'mode': 'open_channel', 'foldername': '%s'%str(channels[i][1]), 'page':'1'})
        li = xbmcgui.ListItem('%s'%channels[i][0], iconImage='%s'%channels[i][2])

        rem_uri = build_url({'mode': 'rem_channel', 'channel_id': '%s'%str(channels[i][1])})
        li.addContextMenuItems([ ('Remove channel', 'RunPlugin(%s)'%rem_uri)])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)



    url = build_url({'mode': 'add_channel', 'foldername': '%s'%foldername})
    li = xbmcgui.ListItem('[COLOR green]Add channel to[/COLOR][COLOR blue] %s[/COLOR]'%foldername, iconImage='https://cdn4.iconfinder.com/data/icons/linecon/512/add-512.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='open_channel':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    page=dicti['page'][0]
    id=dicti['foldername'][0]
    
    game_list=get_latest_from_channel(id,page)
    next_page=game_list[0]
    for i in range(1,len(game_list)):
        title=game_list[i][0].encode('utf8').decode('ascii','ignore')
        video_id=game_list[i][1]
        thumb=game_list[i][2]
        desc=game_list[i][3]
        #link='plugin://plugin.video.youtube/?action=play_video&videoid='+video_id
        
        #uri='plugin://plugin.video.youtube/?action=play_video&videoid='+video_id
        uri = build_url({'mode': 'play_yt', 'foldername': '%s'%title, 'link' : '%s'%video_id})
        li = xbmcgui.ListItem('%s'%title, iconImage=thumb)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=uri, listitem=li,isFolder=True)

    uri = build_url({'mode': 'open_channel', 'foldername': '%s'%id, 'page' : '%s'%next_page})

    li = xbmcgui.ListItem('Next Page >>', iconImage=thumb)
    #li.setInfo('video', { 'title': '%s'%title , 'plot':'%s'%desc})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=uri, listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0]=='play_yt':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    link='plugin://plugin.video.youtube/?action=play_video&videoid='+dicti['link'][0]
    xbmc.executebuiltin('PlayMedia(%s)'%link)


elif mode[0]=='add_channel':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    foldername=dicti['foldername'][0]
    
    keyboard = xbmc.Keyboard('', 'Search channel:', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        channel_name = keyboard.getText()
    


        results=search_channel(channel_name)
        print (results)
        result_list=[]
        for i in range(len(results)):
            result_list+=[results[i][0]]
        dialog = xbmcgui.Dialog()
        index = dialog.select('Choose', result_list)
        if index>-1:
            channel_id=results[index][1]
            channel_name=results[index][0]
            thumb=results[index][2]

            add_channel(foldername,channel_name,channel_id,thumb)
    xbmc.executebuiltin("Container.Refresh")


elif mode[0]=='rem_channel':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    channel_id=dicti['channel_id'][0]
    remove_channel(channel_id)
    xbmc.executebuiltin("Container.Refresh")

elif mode[0]=='rem_folder':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    foldername=dicti['foldername'][0]
    remove_folder(foldername)
    xbmc.executebuiltin("Container.Refresh")

elif mode[0]=='erase_all':
    ret = xbmcgui.Dialog().yesno('Erase database', 'Do you wish to erase your Youtube Channels database?' ) 
    
    if ret:       

        delete_database()
        xbmcgui.Dialog().ok("Youtube Channels", "Successfully erased folder database!")




