from __future__ import unicode_literals
import urllib2
import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
from BeautifulSoup import BeautifulSoup as bs
import urlresolver
import datetime
import json


YOUTUBE_API_KEY='AIzaSyAO7A3iaRS6RJOYUf-o9caPPK-aiMcrnEk'

def read_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:33.0) Gecko/20100101 Firefox/33.0')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link.decode('utf-8')


def get_archives():
    url='http://nbahd.com/'
    req = urllib2.Request(url=url,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request=urllib2.urlopen(req)
    html=request.read()
    soup=bs(html)


    tag=soup.findAll('div',{'id':'archives-2'})[0]

    arh=tag.findAll('li')
    linksout=[]
    for i in range(len(arh)):
        name=arh[i].findAll('a')[0].getText()
        link=arh[i].findAll('a')[0]['href']
        linksout.append([name,link])
    return linksout
def get_game_links_from_date(date):   # date in format yyyy/mm/dd
    basic_url='http://nbahd.com/'
    if basic_url not in date:

        dates=date.split('/')
        year=dates[0]
        month=dates[1]
        day=dates[2]

        url=basic_url + '/%s/%s/%s'%(year,month,day)
    else:
        url=date
    req = urllib2.Request(url=url,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request=urllib2.urlopen(req)
    html=request.read()
    soup=bs(html)

    help_list=[]
    game_links=[]
    help_list=soup.findAll('a',{'class':'clip-link'})

    for i in range(len(help_list)):
        game_link=help_list[i]['href']
        title=help_list[i]['title']
        img=help_list[i].findAll('span')[0].findAll('img')[0]['src']
        title=title.encode('ascii','ignore').decode()
        game_links+=[[game_link,title,img]]



    return game_links


def get_parts_from_game_link(game_link):
    req = urllib2.Request(url=game_link,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request=urllib2.urlopen(req)
    html=request.read()
    soup=bs(html)


    tag=soup.findAll('div',{'class':'entry-content rich-content'})[0]
    links=tag.findAll('a')
    part_links=[]
    for i in range(len(links)):
        link=links[i]['href']
        if 'http://nbahd.com/' in link:
            part_links+=[link]

    return part_links

#print(get_parts_from_game_link('http://nbahd.com/2015/04/13/nuggets-clippers-apr-13-2015/'))

def get_video_from_part_link(part_link):
    reg='file: "(.+?)"'
    pattern=re.compile(reg)



    basic_url='http://nbahd.com/'
    req = urllib2.Request(url=part_link,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request=urllib2.urlopen(req)
    html=request.read()
    soup=bs(html)
    try:
        tag=soup.findAll('div',{'class':'page-content rich-content'})[0]
    except:
        tag=soup.findAll('div',{'class':'entry-content rich-content'})[0]
#try:

    tag=tag.findAll('iframe')[0]
    url=tag['src']
    url=basic_url + url
    request=urllib2.urlopen(url)
    html=request.read()
    soup=bs(html)

    try:
        video_tag=re.findall(pattern,html)
        my_addon = xbmcaddon.Addon()
        HD = my_addon.getSetting('quality')
        
        if HD=='false':
            ind=1
        else:
            ind=0
        
        src=video_tag[ind]
    except:
        video_tag=soup.findAll('video')[0]
        my_addon = xbmcaddon.Addon()
        HD = my_addon.getSetting('quality')
        
        if HD=='false':
            ind=1
        else:
            ind=0
        tag=video_tag.findAll('source')[ind]
        src=tag['src']


        
        
    
    return(src)
#except:
    # my_addon = xbmcaddon.Addon()
    # __addonname__=my_addon.getAddonInfo('name')
    # message='Game not available yet!'
    # xbmcgui.Dialog().ok(__addonname__,message)
    return 'Game not available yet'
 
def get_teams_list():
    site='http://nbahd.com'
    req = urllib2.Request(url=site,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request=urllib2.urlopen(req)
    html=request.read()
    soup=bs(html)

    tag=soup.findAll('center')[0]

    a=tag.findAll('a')
    team_links=[]
    for i in range(len(a)):
        link=a[i]['href']
        img=a[i].findAll('img')[0]['src']
        name=link.replace('http://nbahd.com/tag/','').replace('/','')
        name=name.replace('-',' ').title()
        team_links+=[[link,name,img]]
    return team_links


def get_latest_from_youtube(page):
    if page=='1':
        req_url='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=20&playlistId=UUWJ2lWNubArHWmf3FIHbfcQ&key='+YOUTUBE_API_KEY
    else:
        req_url='https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&pageToken=%s&maxResults=20&playlistId=UUWJ2lWNubArHWmf3FIHbfcQ&key='%page+YOUTUBE_API_KEY
    read=read_url(req_url)
    decoded_data=json.loads(read)
    listout=[]
    next_page=decoded_data['nextPageToken']
    listout.append(next_page)
    for x in range(0, len(decoded_data['items'])):
        title=decoded_data['items'][x]['snippet']['title']
        video_id=decoded_data['items'][x]['snippet']['resourceId']['videoId']
        thumb=decoded_data['items'][x]['snippet']['thumbnails']['high']['url']
        desc=decoded_data['items'][x]['snippet']['description']
        listout.append([title,video_id,thumb,desc])
    return listout

                

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)


if mode is None:
    url = build_url({'mode': 'game_menu', 'foldername': 'Games'})
    li = xbmcgui.ListItem('Games', iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    url = build_url({'mode': 'teams', 'foldername': 'Teams'})
    li = xbmcgui.ListItem('Teams', iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    url = build_url({'mode': 'search', 'foldername': 'Search'})
    li = xbmcgui.ListItem('Search', iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    url = build_url({'mode': 'yt', 'foldername': 'NBA on Youtube', 'page':'1'})
    li = xbmcgui.ListItem('NBA on Youtube', iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    
    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0]=='game_menu':
    url = build_url({'mode': 'games', 'foldername': 'By Date', 'page':'first','date':'http://nbahd.com/'})
    li = xbmcgui.ListItem('By Date', iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    url = build_url({'mode': 'by_month', 'foldername': 'By Month'})
    li = xbmcgui.ListItem('By Month', iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    
    
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='by_month':
    list_arh=get_archives()

    for i in range(len(list_arh)):
        url = build_url({'mode': 'games', 'foldername': '%s'%(list_arh[i][0]), 'page':'first', 'date': '%s'%(list_arh[i][1])})
        li = xbmcgui.ListItem('%s'%(list_arh[i][0]), iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)



    

elif mode[0] == 'dates':
    basic_url='http://nbahd.com/'
    now = datetime.datetime.now()
    okay=1
    while okay:
        year=now.strftime("%Y")
        month=now.strftime("%m")
        day=now.strftime("%d")
        if day in ('1.2.3.4.5.6.7.8.9'):
            day='0'+d
        if month in ('1.2.3.4.5.6.7.8.9'):
            month='0'+m
        url=basic_url + '%s/%s/%s'%(year,month,day)
        try:
            request=urllib2.urlopen(url)
            html=request.read()
            soup=bs(html)
        
            #tag=soup.findAll('h1',{'class':'entry-title'})[0].getText()
            if '404 Not Found' in html:
                now=now-datetime.timedelta(hours=24)
                print('LALALALLALALALALAL je')
            okay=0

        except:
            now=now-datetime.timedelta(hours=24)

    
    for i in range(30):
        year=now.strftime("%Y")
        month=now.strftime("%m")
        day=now.strftime("%d")
        f_name='%s/%s/%s'%(year,month,day)
        url = build_url({'mode': 'games', 'foldername': '%s'%f_name, 'date' : '%s'%f_name})
        li = xbmcgui.ListItem('%s'%f_name, iconImage='http://www.thesportsmecca.com/wp-content/uploads/2015/01/jose-calderon-logo-nba.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
        now=now-datetime.timedelta(hours=24)
    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0]=='games':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    date=dicti['date'][0]
    print(date)
    try:
        page=dicti['page'][0]
    except:
        page=0
    print(page)
    game_list=get_game_links_from_date(date)

    for i in range(len(game_list)):
        url = build_url({'mode': 'game', 'foldername': '%s'%game_list[i][1], 'link' : '%s'%game_list[i][0], 'img': '%s'%(game_list[i][2])})
        li = xbmcgui.ListItem('%s'%game_list[i][1], iconImage='%s'%game_list[i][2])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    #print(date)
    if 'tag' in date or page=='first' or 'page' in date:

        if 'page'not in date:
            linky=date+'page/2/'
        else:
        

            page_num=str(int(date[-2])+1)
            linky=date[:-2] + '%s/'%page_num


        print (linky)
        url = build_url({'mode': 'games', 'foldername': 'Next Page >', 'date' : '%s'%linky})
        li = xbmcgui.ListItem('Next Page >', iconImage='http://www.glib.com/next.gif')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='game':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    link=dicti['link'][0]
    game=dicti['foldername'][0]
    img=dicti['img'][0]
    part_list=get_parts_from_game_link(link)
    pom=1
    if part_list==[]:
        part_list=[get_video_from_part_link(link)]
        pom=0
    for i in range(len(part_list)):
        if pom==1:
            link=get_video_from_part_link(part_list[i])
        else:
            link=part_list[i]
        if  link!='Game not available yet':
            li = xbmcgui.ListItem('Part %s'%(i+1), iconImage=img)
            li.setInfo('video', { 'title': '%s - Part %s'%(game,i+1)})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=link, listitem=li)
        else:
            li = xbmcgui.ListItem('%s'%link, iconImage=img)
            
            xbmcplugin.addDirectoryItem(handle=addon_handle, url='.', listitem=li)




    xbmcplugin.endOfDirectory(addon_handle)   


elif mode[0]=='teams':
    team_list=get_teams_list()
    for i in range(len(team_list)):
        link=team_list[i][0]
        name=team_list[i][1]
        img=team_list[i][2]

        url = build_url({'mode': 'games', 'foldername': '%s'%name, 'date' : '%s'%link})
        li = xbmcgui.ListItem('%s'%name, iconImage=img)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='search':
    keyboard = xbmc.Keyboard('', 'Search', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        query = keyboard.getText()
    print('Search query: ',query)

    date='http://nbahd.com/?s='+query.replace(' ','+')

    game_list=get_game_links_from_date(date)

    for i in range(len(game_list)):
        url = build_url({'mode': 'game', 'foldername': '%s'%game_list[i][1], 'link' : '%s'%game_list[i][0], 'img': '%s'%(game_list[i][2])})
        li = xbmcgui.ListItem('%s'%game_list[i][1], iconImage='%s'%game_list[i][2])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)


elif mode[0]=='yt':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    page=dicti['page'][0]
    
    game_list=get_latest_from_youtube(page)
    next_page=game_list[0]
    for i in range(1,len(game_list)):
        title=game_list[i][0].encode('utf8').decode('ascii','ignore')
        video_id=game_list[i][1]
        thumb=game_list[i][2]
        desc=game_list[i][3]
        link='plugin://plugin.video.youtube/?action=play_video&videoid='+video_id
        print(thumb)
        uri = build_url({'mode': 'play_yt', 'foldername': '%s'%title, 'link' : '%s'%video_id})

        li = xbmcgui.ListItem('%s'%title, iconImage=thumb)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=uri, listitem=li,isFolder=True)

    uri = build_url({'mode': 'yt', 'foldername': 'Next Page', 'page' : '%s'%next_page})

    li = xbmcgui.ListItem('Next Page >>', iconImage=thumb)
    #li.setInfo('video', { 'title': '%s'%title , 'plot':'%s'%desc})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=uri, listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0]=='play_yt':
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    link='plugin://plugin.video.youtube/?action=play_video&videoid='+dicti['link'][0]
    xbmc.executebuiltin('PlayMedia(%s)'%link)

