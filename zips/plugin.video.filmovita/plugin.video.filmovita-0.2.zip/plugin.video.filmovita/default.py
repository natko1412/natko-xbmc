# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib2
#import urllib2 as urllib2
import re
from BeautifulSoup import BeautifulSoup as bs
import itertools
import urlresolver
import json

###########################################################
#functions
category=['akcijski filmovi','animirani filmovi','avanturisticki filmovi','dokumentarni filmovi','domaci filmovi','drame',
                    'fantazije','horor filmovi','filmovi komedije','kriminalisticki filmovi','povijesni filmovi','ratni filmovi',
                    'romanticni filmovi','sf filmovi','sinkronizirani crtici','sport','sportski filmovi','trileri','westerni']
def get_links(url):
    def get_string(text):
        string=text
        #numbers
        string=string.replace('\\u0030','0').replace('\\u0031','1').replace('\\u0032','2').replace('\\u0033','3').replace('\\u0034','4').replace('\\u0035','5').replace('\\u0036','6').replace('\\u0037','7').replace('\\u0038','8').replace('\\u0039','9')
        #special chars
        string=string.replace('\\u0020',' ').replace('\\u0021','!').replace('\\u0022','"').replace('\\u0023','#').replace('\\u0024','$').replace('\\u0025','%').replace('\\u0026','&')  
        string=string.replace('\\u0027',"'").replace('\\u0028','(').replace('\\u0029',')').replace('\\u002a','*').replace('\\u002b','+').replace('\\u002c',',').replace('\\u002d','-').replace('\\u002e','.').replace('\\u002f','/')    
        string=string.replace('\\u003a',':').replace('\\u003b',';').replace('\\u003c','<').replace('\\u003d','=').replace('\\u003e','>').replace('\\u003f','?').replace('\\u0040','@')  
        string=string.replace('\\u005b','[').replace('\\u005c','\\').replace('\\u005d',']').replace('\\u005e','^').replace('\\u005f','_').replace('\\u0060','`')
        string=string.replace('\\u007b','{').replace('\\u007c','|').replace('\\u007d','}').replace('\\u007e','~')
        #eng alpha
        string=string.replace('\\u0041','A').replace('\\u0042','B').replace('\\u0043','C').replace('\\u0044','D').replace('\\u0045','E').replace('\\u0046','F').replace('\\u0047','G').replace('\\u0048','H').replace('\\u0049','I').replace('\\u004a','J').replace('\\u004b','K').replace('\\u004c','L').replace('\\u004d','M').replace('\\u004e','N').replace('\\u004f','O')
        string=string.replace('\\u0050','P').replace('\\u0051','Q').replace('\\u0052','R').replace('\\u0053','S').replace('\\u0054','T').replace('\\u0055','U').replace('\\u0056','V').replace('\\u0057','W').replace('\\u0058','X').replace('\\u0059','Y').replace('\\u005a','Z')
        
        string=string.replace('\\u0061','a').replace('\\u0062','b').replace('\\u0063','c').replace('\\u0064','d').replace('\\u0065','e').replace('\\u0066','f').replace('\\u0067','g').replace('\\u0068','h').replace('\\u0069','i').replace('\\u006a','j').replace('\\u006b','k').replace('\\u006c','l').replace('\\u006d','m').replace('\\u006e','n').replace('\\u006f','o')
        string=string.replace('\\u0070','p').replace('\\u0071','q').replace('\\u0072','r').replace('\\u0073','s').replace('\\u0074','t').replace('\\u0075','u').replace('\\u0076','v').replace('\\u0077','w').replace('\\u0078','x').replace('\\u0079','y').replace('\\u007a','z')

        #hrv abc
        string=string.replace('\\u00d0','D').replace('\\u0106','C').replace('\\u0107','c').replace('\\u010c','C').replace('\\u010d','c').replace('\\u0160','S').replace('\\u0161','s').replace('\\u017d','Z').replace('\\u017e','z')
        string=string.replace('\\u000a','\n')
        return string

    def check(lista):
        lista=lista
        for i in range(len(lista)):
            if 'klipovito' in lista[i]:
                lista.pop(i)
                check(lista)
                break
            elif 'filmovita' in lista[i]:
                lista.pop(i)
                check(lista)
                break
            elif 'facebook' in lista[i]:
                lista.pop(i)
                check(lista)
                break
            elif 'twitter' in lista[i]:
                lista.pop(i)
                check(lista)
                break
            elif 'tvprofil' in lista[i]:
                lista.pop(i)
                check(lista)
                break
        

    reg='href="(.+?)"'
    pat=re.compile(reg)

    reg2='src="(.+?)"'
    pat2=re.compile(reg2)

    reg3='<iframe src="(.+?)"'
    pat3=re.compile(reg3)

    reg4='<IFRAME SRC="(.+?)"'
    pat4=re.compile(reg4)

    reg5='<iframe src="http://filmovita.com/links/(.+?)"'
    pat5=re.compile(reg5)


    url=url

    req = urllib2.Request(url=url,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request = urllib2.urlopen(req)
    html=request.read()

    soup=bs(html)
    try:
        tag=soup.findAll('span')
        for i in range(len(tag)):
            test=str(tag[i])
            if '\\u00' in test:
                ind=i
                break
            
        tag=soup.findAll('span')[ind]
        tag=get_string(str(tag))
        linkovi=re.findall(pat,tag)
        check(linkovi)
        if linkovi==[]:
            raise
    except:
        try:
            linkovi=''
            tag=soup.find("div", {"class":"entry-content clearfix"})
            tags=tag.findAll('p')
            for i in range(len(tags)):
                pp=tags[i]#.decode(sys.stdin.encoding)
                linkovi+=str(pp)
            linkovi=re.findall(pat,linkovi)
            check(linkovi)
            if linkovi==[]:
                raise 
        except:
            try:
                linkovi=''
                tag=soup.find("div", {"class":"entry-content clearfix"})
                tags=tag.findAll('p')
                for i in range(len(tags)):
                    pp=tags[i]#.decode(sys.stdin.encoding)

                    linkovi+=str(pp)
                linkovi=re.findall(pat2,linkovi)

                linkovi.pop(0)
                linkovi.pop(0)
                check(linkovi)
                if linkovi==[]:
                    raise
            except:
                try:
                    linkov=str(html)
                    linkovi=re.findall(pat3,linkov)
                    linkovi+=re.findall(pat4,linkov)
                    check(linkovi)
                    if linkovi==[]:
                        raise
                except:
                    try:
                        linkov=str(html)
                        
                        lin=re.findall(pat5,linkov)[0]
                        lin='http://filmovita.com/links/'+lin
                        req = urllib2.Request(url=lin,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
                        request = urllib2.urlopen(req)
                        html=request.read()

                        soup=bs(html)
                        linkovi=re.findall(pat,str(html))
                        check(linkovi)
                        if linkovi==[]:
                            raise
                    except:
                        linkovi=''
                        linkovi=re.findall(pat,str(html))
                        check(linkovi)

                    
                
    return(linkovi)

def get_list_of_movies_genre(url,tag_categ):
    category_tags=['akcijski filmovi','animirani filmovi','avanturisticki filmovi','dokumentarni filmovi','domaci filmovi','drame',
                    'fantazije','horor filmovi','filmovi komedije','kriminalisticki filmovi','povijesni filmovi','ratni filmovi',
                    'romanticni filmovi','sf filmovi','sinkronizirani crtici','sport','sportski filmovi','trileri','westerni']
    if tag_categ in category_tags:
        pass
    else:
        return ['pogreska']


    reg='href="(.+?)"'
    pat=re.compile(reg)

    reg2='src="(.+?)"'
    pat2=re.compile(reg2)

    reg3='<iframe src="(.+?)"'
    pat3=re.compile(reg3)

    reg4='<IFRAME SRC="(.+?)"'
    pat4=re.compile(reg4)

    reg5='<script type="text/javascript" src="(.+?)"'
    pat5=re.compile(reg5)

    reg6='http://www.imdb.com/title/(.+?)/'
    imdb=re.compile(reg6)
    url=url

    req = urllib2.Request(url=url,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request = urllib2.urlopen(req)
    html=request.read()

    soup=bs(html)

    imena=[]
    links=[]
    linkks=[]
    te=soup.find("img",{"alt":"%s"%tag_categ})
    tag=te.findNext("ul", {"class":"lcp_catlist"})
    tags=tag.findAll('a')
    linkovi=''
    for i in range(len(tags)):
        pp=tags[i]
        ime=pp.getText()

        pp=unicode(str(tags[i]),'utf-8')
        imena+=[ime]
        
        linkovi+=pp
        linkovi+='\n'
    linkovi=linkovi.encode('utf-8')
    links=re.findall(pat,linkovi)
    for i in range(len(imena)):
        linkks+=[[links[i],imena[i]]]
    return linkks

def get_latest(site):
    reg='href="(.+?)"'
    pat=re.compile(reg)

    req = urllib2.Request(url=site,headers={'User-Agent':' Mozilla/5.0 (Windows NT 6.1; WOW64; rv:12.0) Gecko/20100101 Firefox/12.0'})
    request = urllib2.urlopen(req)
    html=request.read()
    soup=bs(html)
    linksout=[]
    tags=soup.findAll('article')
    for i in range(len(tags)):
        names=tags[i].find('h1',{'class':'entry-title'})
        ime=names.getText()
        link=re.findall(pat,str(names))[0]
        linksout+=[[link,ime]]

    return linksout

def get_list_of_all_movies():
    site='http://www.filmovita.com/lista-svih-filmova/'
    category_tags=['akcijski filmovi','animirani filmovi','avanturisticki filmovi','dokumentarni filmovi','domaci filmovi','drame',
                    'fantazije','horor filmovi','filmovi komedije','kriminalisticki filmovi','povijesni filmovi','ratni filmovi',
                    'romanticni filmovi','sf filmovi','sinkronizirani crtici','sport','sportski filmovi','trileri','westerni']
    lista=[]
    for i in range(len(category_tags)):
        pom_lista=[]
        pom_lista=get_list_of_movies_genre(site,category_tags[i])
        for j in range(len(pom_lista)):
            lista+=[pom_lista[j]]
    return lista
def search_movies(query):
    indexi=[]
    lista=get_list_of_all_movies()
    for i in range(len(lista)):
        if query.lower() in (lista[i][1]).lower():
            indexi+=[lista[i]]

    return indexi
#==============================================================================================================================0


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'latest', 'foldername': 'Zadnje dodano'})
    li = xbmcgui.ListItem('Zadnje dodano', iconImage='https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/zadnje.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    url = build_url({'mode': 'cats', 'foldername': 'Kategorije'})
    li = xbmcgui.ListItem('Kategorije', iconImage='https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/kategorije.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)


    url = build_url({'mode': 'search', 'foldername': 'Pretraga'})
    li = xbmcgui.ListItem('Pretraga', iconImage='https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/pretraga.jpg')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='search':

    keyboard = xbmc.Keyboard('', 'Pretraga', False)
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        query = keyboard.getText()
    print(query)
    lista=search_movies(query)
    for i in range(len(lista)):
        ime=lista[i][1]
        ind=ime.index('(')
        title=ime[:ind]#.encode('utf-8').replace('&#8217;',"'").replace('&#038;',"&").decode('utf-8')
        try:
            title=ime[:ind].replace('(','').replace(')','').replace(' ','+')
            year=ime[ind:].replace('(','').replace(')','')
            link='http://www.omdbapi.com/?t=%s&y=%s&plot=short&r=json'%(title,year)
            request = urllib2.urlopen(link)
            html=request.read()
            html=str(html)
            data = json.loads(html)
        except:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            pass
        
#=============meta
        if data['Response']==u'True':
            print('response okay')

            try:
                
                title=data[u'Title']
                print(title)
            except:
                pass
            try:
                year=data[u'Year']
            except:
                pass
            try:
                poster=data['Poster']
            except:
                poster=''
            try:
                released=data['Released']
            except:
                released=''
            try:
                runtime=data['Runtime']
            except:
                runtime=''
            try:
                genre=data['Genre']
            except:
                genre=''
            try:
                director=data['Director']
            except:
                director=''
            try:
                actors=data['Actors']
            except:
                actors=''
            try:
                plot=data['Plot']
            except:
                plot=''
            try:
                lang=data['Language']
            except:
                lang=''
            try:
                imdbRating=data['imdbRating']
                if imdbRating=='N/A':
                    imdbRating='5.0'
            except:
                imdbRating=''
            try:
                imdbID=data['imdbID']
            except:
                imdbID=''
            try:
                votes=data['imdbVotes']
            except:
                votes=''
            try:
                typ=data['Type']
            except:
                typ=''


        else:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            released='5-5-2005'
            runtime='100'
            genre='Comedy'
            director='-'
            actors='-'
            plot='-'
            lang='English'
            imdbRating='5.0'
            imdbID='-'
            votes='0'
            year='2001'
            typ='video'
        title=title#.replace('&#8217;',"'").replace('&#038;',"&")
        try:
            url = build_url({'mode': 'play"%s"'%lista[i][0], 'foldername':'bla' ,'poster': poster,'genre': genre,'year': year,'title': title,'rating':float(imdbRating),'director': director,'plotline': plot,'duration': runtime,'votes':votes})
        except:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            released='5-5-2005'
            runtime='100'
            genre='Comedy'
            director='-'
            actors='-'
            plot='-'
            lang='English'
            imdbRating='5.0'
            imdbID='-'
            votes='0'
            year='2001'
            typ='video'
            url = build_url({'mode': 'play"%s"'%lista[i][0], 'foldername':'bla' ,'poster': poster,'genre': genre,'year': '-','title': title,'rating':float(imdbRating),'director': '-','plotline': '.','duration': runtime,'votes':votes})
        
        li = xbmcgui.ListItem( '%s'%ime, iconImage=poster)
        li.setInfo('video', { 'genre': genre,
                            'year': year,
                            'title': title,
                            'rating':float(imdbRating),
                            'director': director,
                            'plotline': plot,
                            'duration': runtime,
                            'votes':votes})
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='latest':
    site='http://www.filmovita.com'
    lista=get_latest(site)

    for i in range(len(lista)):
        ime=lista[i][1]
        ind=ime.index('(')
        title=ime[:ind].encode('utf-8').replace('&#8217;',"'").replace('&#038;',"&").decode('utf-8')
        try:
            title=ime[:ind].replace('(','').replace(')','').replace(' ','+')
            year=ime[ind:].replace('(','').replace(')','')
            link='http://www.omdbapi.com/?t=%s&y=%s&plot=short&r=json'%(title,year)
            request = urllib2.urlopen(link)
            html=request.read()
            html=str(html)
            data = json.loads(html)
        except:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            pass
        
#=============meta
        if data['Response']==u'True':
            print('response okay')
            try:
                
                title=data[u'Title']
            except:
                pass
            try:
                year=data[u'Year']
            except:
                pass
            try:
                poster=data['Poster']
            except:
                poster=''
            try:
                released=data['Released']
            except:
                released=''
            try:
                runtime=data['Runtime']
            except:
                runtime=''
            try:
                genre=data['Genre']
            except:
                genre=''
            try:
                director=data['Director']
            except:
                director=''
            try:
                actors=data['Actors']
            except:
                actors=''
            try:
                plot=data['Plot']
            except:
                plot=''
            try:
                lang=data['Language']
            except:
                lang=''
            try:
                imdbRating=data['imdbRating']
                if imdbRating=='N/A':
                    imdbRating='5.0'
            except:
                imdbRating=''
            try:
                imdbID=data['imdbID']
            except:
                imdbID=''
            try:
                votes=data['imdbVotes']
            except:
                votes=''
            try:
                typ=data['Type']
            except:
                typ=''


        else:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
        title=title.replace('&#8217;',"'").replace('&#038;',"&")
        url = build_url({'mode': 'play"%s"'%lista[i][0], 'foldername':'bla' ,'poster': poster,'genre': genre,'year': year,'title': title,'rating':float(imdbRating),'director': director,'plotline': plot,'duration': runtime,'votes':votes})
        li = xbmcgui.ListItem( '%s'%ime, iconImage=poster)
        li.setInfo('video', { 'genre': genre,
                            'year': year,
                            'title': title,
                            'rating':float(imdbRating),
                            'director': director,
                            'plotline': plot,
                            'duration': runtime,
                            'votes':votes})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif 'play' in mode[0]:
    regg='play"(.+?)"'
    pattern=re.compile(regg)

    aaaa=sys.argv[2][1:]
    pom=str(mode[0])
    dicti=urlparse.parse_qs(sys.argv[2][1:])
    print(aaaa)
    try:
        link=re.findall(pattern,pom)[0]
        year=dicti['year'][0]
        title=dicti['title'][0]
        plot=dicti['plotline'][0]
        img=dicti['poster'][0]
    except:
        title='Link'
        img='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
        year='2001'
        plot=' '
    lista=get_links(str(link))
    print(lista)
    ind=0
    for i in range(len(lista)):
        url=urlresolver.resolve(lista[i])
        if url:
            ind+=1
            li = xbmcgui.ListItem('%s: Link %s'%(title,ind), iconImage=img)
            li.setInfo('video', { 'year': year,
                            'title': title,
                            'plotline': plot})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=str(url), listitem=li)
        else:
            pass
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='cats':
    category_tags=[['Akcije','akcijski filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/akcija.jpg'],['Animirani','animirani filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/animirani.jpg'],['Avanture','avanturisticki filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/avanture.jpg'],
    ['Dokumentarci','dokumentarni filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/doku.jpg'],['Domaci filmovi','domaci filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/domaci.jpg'],
                    ['Drame','drame','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/drama.jpg'],['Fantasy','fantazije','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/fantasy.jpg'],['Horori','horor filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/horori.jpg'],['Komedije','filmovi komedije','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/komedije.jpg'],['Kriminalisticki','kriminalisticki filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/krimi.jpg'],
                    ['Povijesni','povijesni filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/povijesni.jpg'],['Ratni','ratni filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/ratni.jpg'],['Romanticni','romanticni filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/romanticni.jpg'],['SF filmovi','sf filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/sf.jpg'],['Sinkronizirani crtani','sinkronizirani crtici','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/animirani.jpg'],
                    ['Sport','sport','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/sport.jpg'],['Sportski filmovi','sportski filmovi','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/sport.jpg'],['Trileri','trileri','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/triler.jpg'],['Westerni','westerni','https://raw.githubusercontent.com/natko1412/repo.natko1412/master/img/western.jpg']]

    for i in range(len(category_tags)):
        url = build_url({'mode': 'category"%s"-img"%s"'%(category_tags[i][1],category_tags[i][2]), 'foldername': '%s'%category_tags[i][0]})
        li = xbmcgui.ListItem('%s'%category_tags[i][0], iconImage=category_tags[i][2])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif 'category' in mode[0]:
    regg='category"(.+?)"'
    pattern=re.compile(regg)
    regg2='-img"(.+?)"'
    patt2=re.compile(regg2)

    pom=str(mode[0])
    
    link=re.findall(pattern,pom)[0]
    img=re.findall(patt2,pom)[0]
    site='http://www.filmovita.com/lista-svih-filmova/'
    
    lista=get_list_of_movies_genre(site,link)
    print(lista)

    for i in range(len(lista)):
        #link=str(lista[i][0].encode('utf-8'))
        #ime=str(lista[i][1].encode('utf-8'))

        ime=lista[i][1]
        try:
            ind=ime.index('(')
            title=ime[:ind]#.encode('utf-8').replace('&#8217;',"'").replace('&#038;',"&").decode('utf-8')
       
            title=ime[:ind].replace('(','').replace(')','').replace(' ','+')
            year=ime[ind:].replace('(','').replace(')','')
            link='http://www.omdbapi.com/?t=%s&y=%s&plot=short&r=json'%(title,year)
            request = urllib2.urlopen(link)
            html=request.read()
            html=str(html)
            data = json.loads(html)
        except:
            title=ime
            data={u'Response':u'True'}
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            pass
        
#=============meta
        if data['Response']==u'True':
            print('response okay')

            try:
                
                title=data[u'Title']
                print(title)
            except:
                pass
            try:
                year=data[u'Year']
            except:
                pass
            try:
                poster=data['Poster']
            except:
                poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            try:
                released=data['Released']
            except:
                released='5-5-2005'
            try:
                runtime=data['Runtime']
            except:
                runtime='100'
            try:
                genre=data['Genre']
            except:
                genre='Comedy'
            try:
                director=data['Director']
            except:
                director='-'
            try:
                actors=data['Actors']
            except:
                actors='-'
            try:
                plot=data['Plot']
            except:
                plot='-'
            try:
                lang=data['Language']
            except:
                lang='English'
            try:
                imdbRating=data['imdbRating']
                if imdbRating=='N/A':
                    imdbRating='5.0'
            except:
                imdbRating='5.0'
            try:
                imdbID=data['imdbID']
            except:
                imdbID='-'
            try:
                votes=data['imdbVotes']
            except:
                votes='0'
            try:
                typ=data['Type']
            except:
                typ='video'


        else:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            released='5-5-2005'
            runtime='100'
            genre='Comedy'
            director='-'
            actors='-'
            plot='-'
            lang='English'
            imdbRating='5.0'
            imdbID='-'
            votes='0'
            typ='video'
            year='2001'

        title=title#.replace('&#8217;',"'").replace('&#038;',"&")
        try:
            url = build_url({'mode': 'play"%s"'%lista[i][0], 'foldername':'bla' ,'poster': poster,'genre': genre,'year': year,'title': title,'rating':float(imdbRating),'director': director,'plotline': plot,'duration': runtime,'votes':votes})
        except:
            poster='http://1.bp.blogspot.com/-LT8A8dNX77Y/UxvogRTCNyI/AAAAAAAABNk/D91p8QnoshA/s1600/Blank-Case.png'
            released='5-5-2005'
            runtime='100'
            genre='Comedy'
            director='-'
            actors='-'
            plot='-'
            lang='English'
            imdbRating='5.0'
            imdbID='-'
            votes='0'
            typ='video'
            year='2001'
            url = build_url({'mode': 'play"%s"'%lista[i][0], 'foldername':'bla' ,'poster': poster,'genre': genre,'year': '-','title': 'Movie','rating':float(imdbRating),'director': '-','plotline': '.','duration': runtime,'votes':votes})
        
        li = xbmcgui.ListItem( '%s'%ime, iconImage=poster)
        li.setInfo('video', { 'genre': genre,
                            'year': year,
                            'title': title,
                            'rating':float(imdbRating),
                            'director': director,
                            'plotline': plot,
                            'duration': runtime,
                            'votes':votes})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)
    





    

